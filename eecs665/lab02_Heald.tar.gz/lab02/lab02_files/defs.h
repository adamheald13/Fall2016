/* Definitions of structures and function prototypes */

#ifndef _DEFS_H
#define _DEFS_H

#include "defs2.h"

struct A{
  int in_var1, in_var2;
};

#endif
