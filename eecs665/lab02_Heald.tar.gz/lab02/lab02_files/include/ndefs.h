/* Definitions of structures and function prototypes */

#ifndef _DEFS_H
#define _DEFS_H

int my_mul(int a, int b);

struct A{
  int in_var1, in_var2;
};

#endif
